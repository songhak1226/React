import './App.css';
import Header from './components/Header';
import CreatePost from './components/CreatePost';
import { Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className='container'>
      <Header/>
      <CreatePost />

    </div>
  );
}

export default App;
