import React, { useState } from 'react';
import '../css/Login.css';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');

  const loginUser = async () => {
    try {
      const response = await axios.post(
        'http://localhost:8099/soolsool/login',
        { mb_id: userId, mb_pw: password },
        { withCredentials: true } // 쿠키를 전송하도록 설정
      );
      console.log(response);
      if (response.status === 200) {
        console.log(response.data);
        window.location.href = '/';
      } else {
        alert('로그인에 실패하였습니다.');
      }
    } catch (error) {
      alert('로그인에 실패하였습니다.');
      console.error(error);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    await loginUser();
  };
  return (
    <div className="login-container">
      <table>
        <tbody>
          <tr>
            <td className="content">
              <h1>로그인</h1>
              <form onSubmit={handleLogin}>
                <div>
                  <input
                    type="text"
                    placeholder="이메일을 입력해주세요."
                    maxLength="10"
                    autoFocus
                    onChange={(e) => setUserId(e.target.value)}
                  />
                  <br />
                  <input
                    type="password"
                    placeholder="비밀번호를 입력해주세요."
                    maxLength="15"
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <br />
                  <button className="login-button" type="submit" onClick={handleLogin}>
                    로그인
                  </button>
                  <br />
                  <button className="join-button">
                    <Link to="/Join">회원가입</Link>
                  </button>
                </div>
              </form>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Login;
