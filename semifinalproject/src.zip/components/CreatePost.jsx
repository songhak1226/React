import React, { useState } from 'react';

const CreatePost = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [file, setFile] = useState(null);

  const onFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    // 서버 API 주소
    const apiUrl = "http://localhost:8099/soolsool/asd";

    const formData = new FormData();
    formData.append("title", title);
    formData.append("content", content);
    formData.append("img", file);

    // API에 게시글 데이터 전송
    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            body: formData,
        });
    
        const json = await response.json();  // 서버 응답을 JSON으로 변환
    
        if (response.ok) {
            if (json.result === "success") {
                alert("게시글 작성 성공");
                setTitle("");
                setContent("");
            } else {
                alert("게시글 작성 실패");
            }
        } else {
            alert("통신 실패");
        }
        console.log(json);
    } catch (error) {
        alert("통신 실패");
        console.error(error);
    }
}

  return (
    <form onSubmit={handleSubmit} style={{ padding: 20 }}>
      <h1>게시글 작성</h1>
      <input
        type="text"
        placeholder="제목"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{ display: "block", width: "100%", marginBottom: 10 }}
      />
      <textarea
        placeholder="내용"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        style={{ display: "block", width: "100%", marginBottom: 10 }}
      />
      <input
        type="file"
        onChange={onFileChange}
        style={{ display: "block", width: "100%", marginBottom: 10 }}
      /> {/* 파일 입력 요소 추가 */}
      <button type="submit">작성하기</button>
    </form>
  );
};


export default CreatePost