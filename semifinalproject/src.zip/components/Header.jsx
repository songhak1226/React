import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    checkLoginStatus();
  }, []);

  const checkLoginStatus = async () => {
    try {
      const response = await axios.get("http://localhost:8099/soolsool/checkLoginStatus", { withCredentials: true });
      if (response.data.loggedIn) {
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:8099/soolsool/logout", {}, { withCredentials: true });
      setIsLoggedIn(false);
    } catch (error) {
      console.error(error);
    }
  };


  return (
    <div className='Headermain'>
      <div><Link to="/">로고</Link></div>
      <div><Link to="/Community">커뮤니티</Link></div>
      <div><Link to="/storage">술창고</Link></div>
      <div><Link to="/info">전통주정보</Link></div>
      <div>
        {isLoggedIn ? (
          <>
            <Link to="/Mypage">마이페이지</Link>
            <button onClick={handleLogout}>로그아웃</button>
          </>
        ) : (
          <Link to="/login">로그인</Link>
        )}
      </div>
    </div>
  );
};

export default Header;
