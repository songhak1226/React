import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {useNavigate } from 'react-router-dom';

const Mypage = () => {
  const [userInfo, setUserInfo] = useState(null);
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [nick, setNick] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const response = await axios.get('http://localhost:8099/soolsool/getUserInfo', { withCredentials: true });
        setUserInfo(response.data);
        setId(response.data.id);
        setPassword(response.data.password);
        setEmail(response.data.email);
        setNick(response.data.nick);
      } catch (error) {
        console.error(error);
      }
    };

    fetchUserInfo();
  }, []);

  const handleSave = async () => {
    if (!id || !password || !email || !nick) {
      setErrorMessage('모든 항목을 입력해주세요.');
      return;
    }
  
    console.log({ mb_id: id, mb_pw: password, mb_email: email, mb_nick: nick });
    try {
      const response = await axios.put(
        'http://localhost:8099/soolsool/update',
        { mb_id: id, mb_pw: password, mb_email: email, mb_nick: nick },
        { withCredentials: true }
      );
  
      console.log(response);
      if (response.status === 200) {
        navigate('/');
      } else {
        setErrorMessage(response.data);
      }
    } catch (error) {
      setErrorMessage('정보 업데이트 중 오류가 발생했습니다.');
    }
  };
  
  
  return (
    <div>
      {userInfo ? (
        <div>
          <h1>Mypage</h1>
          <div>ID: {id}</div>
          <div>Password: <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <div>Email: {email}<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div>nick: {nick}<input type="text" value={nick} onChange={(e) => setNick(e.target.value)} /></div>
          <button onClick={handleSave}>Save Changes</button>
          {errorMessage && <div style={{ color: 'red' }}>{errorMessage}</div>}
        </div>
      ) : (
        <div>Loading...</div>
      )}
    </div>
  );
};

export default Mypage;