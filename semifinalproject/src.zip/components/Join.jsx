import React, { useState } from 'react';
import {useNavigate } from 'react-router-dom';
import axios from 'axios';

const Join = () => {
  const navigate = useNavigate();
  const [duplicateMessage, setDuplicateMessage] = useState('');
  const [formData, setFormData] = useState({
    mb_id: '',
    mb_email: '',
    mb_pw: '',
    mb_pw_confirm: '',
    mb_nick: '',
  });
  
  const checkDuplicate = async () => {
    try {
      const response = await axios.post('http://localhost:8099/soolsool/checkId', {
        mb_id: formData.mb_id,
      });
  
      if (response.data.success) {
        setDuplicateMessage('아이디가 사용 가능합니다.');

      } else {
        setDuplicateMessage('아이디가 중복되었습니다.');

      }
    } catch (error) {
      setDuplicateMessage('아이디가 중복되었습니다.');

    }
  };
  

  const onChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (formData.mb_pw !== formData.mb_pw_confirm) {
      alert('비밀번호가 일치하지 않습니다. 다시 입력해주세요.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8099/soolsool/register', {
        mb_id: formData.mb_id,
        mb_email: formData.mb_email,
        mb_pw: formData.mb_pw,
        mb_nick: formData.mb_nick,
      });
      console.log(response);

      if (response.data.success) {
        alert(response.data.message);
        navigate('/Login');
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error(error);
      alert('회원가입 도중 오류가 발생했습니다. 다시 시도해주세요.');
    }
  };

  return (
    <div className="Join_container">
      <div className="Join_content">
        <form onSubmit={onSubmit} className="Join_content1">
        <div>
          <label htmlFor="mb_id">아이디</label>
          <input
            type="text"
            name="mb_id"
            value={formData.mb_id}
            onChange={onChange}
          />
          <button type="button" onClick={checkDuplicate}>
            체크하기
          </button>
          <span>{duplicateMessage}</span>
        </div>

          <div>
            <label htmlFor="mb_email">이메일</label>
            <input
              type="email"
              name="mb_email"
              value={formData.mb_email}
              onChange={onChange}
            />
          </div>
          <div>
            <label htmlFor="mb_pw">비밀번호</label>
            <input
              type="password"
              name="mb_pw"
              value={formData.mb_pw}
              onChange={onChange}
            />
          </div>
          <div>
            <label htmlFor="mb_pw_confirm">비밀번호 확인</label>
            <input
              type="password"
              name="mb_pw_confirm"
              value={formData.mb_pw_confirm}
              onChange={onChange}
            />
          </div>
          <div>
            <label htmlFor="mb_nick">닉네임</label>
            <input
              type="text"
              name="mb_nick"
              value={formData.mb_nick}
              onChange={onChange}
            />
          </div>
          <button type="submit" className="join_button1">
            회원가입 완료
          </button>
        </form>
      </div>
    </div>
  );
};
export default Join;