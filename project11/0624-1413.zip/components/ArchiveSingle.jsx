import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const ArchiveSingle = () => {
  const { arc_idx } = useParams();
  const [item, setItem] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:8099/soolsool/archive/${arc_idx}`);
        const foundItem = response.data;
        setItem(foundItem.archive);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [arc_idx]);

  if (!item) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <div>작성자 : {item.mb_id}</div>
      <div>작성일: {item.arc_at}</div>
      <div className="arc-idx">
        <h1> 제목 : {item.arc_idx}</h1>
        <br />
      </div>
      <div className="arc-title">
        <p>{item.arc_title}</p>
      </div>
      <img width='500px' src={"data:image/;base64,"+item.arc_file}></img>
    </div>
  );
};

export default ArchiveSingle;